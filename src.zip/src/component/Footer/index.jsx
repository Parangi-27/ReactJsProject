import React from "react";
import "./footer.css";
function Footer(){

    return(
            <>
            <div class="wrapper">
                <center>
                <small>&copy;2022 <strong>Manav & Parangi</strong>, All Rights Reserved</small>
                <nav class="footer-nav">
                    <a href="#">Back to Top</a>
                    {/* <a href="#">Terms of Use</a>
                    <a href="#">Privacy</a> */}
                </nav>
                </center>
            </div>
            </>
    );
}

export default Footer;